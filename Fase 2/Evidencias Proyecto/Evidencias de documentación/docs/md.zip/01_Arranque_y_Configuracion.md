## 1. Propósito

Este documento describe la fase inicial de ejecución de la aplicación **Volvo Dashboard** y su sistema de configuración global.

Registra el comportamiento confirmado en el código fuente actualmente auditado, principalmente `main.py` y `config/settings.py`. Su objetivo es documentar cómo se inicia la aplicación, cómo se prepara el entorno gráfico y cómo se obtiene la configuración necesaria para el funcionamiento del sistema.

La información de este documento representa el **estado actual verificado del código**, por lo que no debe interpretarse como una definición de la arquitectura futura.

---

## 2. Punto de entrada

El archivo `main.py` constituye el punto de entrada directo de la aplicación.

Su responsabilidad durante el arranque incluye:

- Preparar determinadas configuraciones del entorno gráfico.
    
- Inicializar `QApplication`.
    
- Configurar el estilo y la paleta visual de Qt.
    
- Cargar la hoja de estilos global.
    
- Configurar el icono de la aplicación.
    
- Mostrar el Splash Screen.
    
- Controlar la transición hacia `MainWindow`.
    
- Iniciar el ciclo principal de eventos de Qt.
    

---

## 3. Flujo de inicialización

El proceso de arranque sigue actualmente una secuencia controlada mediante un `QTimer` asociado al Splash Screen.

### 3.1 Configuración del entorno gráfico

Al comenzar la ejecución, `main.py` establece la variable de entorno:

`QT_QPA_PLATFORM=windows:darkmode=0`

Esto se utiliza para desactivar el modo oscuro de Windows para la aplicación.

### 3.2 Inicialización de QApplication

Se crea la instancia principal de PyQt6 mediante:

`QApplication(sys.argv)`

Este objeto constituye la base del entorno gráfico sobre el cual se ejecuta la aplicación.

### 3.3 Configuración visual

La aplicación fuerza el estilo de Qt denominado `Fusion` y establece explícitamente una paleta de colores claros para determinados elementos de la interfaz.

### 3.4 Carga de estilos

`main.py` utiliza `load_stylesheet` para leer y aplicar el archivo:

`src/assets/styles.qss`

Este archivo contiene estilos globales utilizados por la interfaz.

### 3.5 Configuración del icono

Se carga el recurso:

`src/assets/splash_logo.png`

y se procesa mediante `create_white_background_icon` para generar el icono utilizado por la aplicación.

Además, se utiliza configuración específica de Windows mediante `ctypes` para establecer un identificador de aplicación que permite agrupar correctamente el proceso en la barra de tareas.

### 3.6 Splash Screen

Se instancia `CustomSplashScreen` como pantalla inicial de carga.

El Splash Screen utiliza una ventana sin bordes, transparencia y efectos visuales para presentar el proceso de inicio al usuario.

### 3.7 Temporizador y creación de MainWindow (actualizado 14-09-2026 — ya no depende de ticks fijos)

**Corregido:** el flujo anterior de este documento describía una transición gobernada por ticks fijos del `QTimer` (tick 75 = instanciar `MainWindow`, tick 100 = mostrarla). Ese mecanismo ya no existe en el código.

`start_animation()` (`main.py:140-147`) instancia `MainWindow()` **de inmediato**, en paralelo al arranque de la animación visual, en vez de esperar a un punto fijo del contador (comentario explícito en el código: *"en vez de esperar a un punto fijo del contador"*). Al construirse, `MainWindow` ya dispara su propia carga de datos en `QThread` (ver [[02_Motor_de_Datos_Core]]), y el splash se suscribe a sus señales `data_manager.data_ready`/`data_manager.load_error` (`main.py:153-154`).

El `QTimer` (25 ms por ciclo) solo controla la **animación visual** de la barra de progreso (`update_progress`, `main.py:178-199`), con mensajes de estado en los ticks 15, 45 y 75. La barra tiene un **tope visual de 95%** (`min(self.counter, 95)`): nunca llega a 100% por sí sola. Si el contador alcanza 95 antes de que la carga real termine, el timer se detiene y el texto cambia a "Esperando finalización de carga de datos...".

### 3.8 Finalización del Splash e inicio del Event Loop

El cierre real del splash lo dispara `_on_app_ready()` (`main.py:158-166`), dispuesto tanto por `data_ready` (carga exitosa) como por `load_error` (error controlado) — cualquiera de las dos señales significa que `MainWindow` ya sabe qué mostrar. `_finalizar()` (`main.py:168-176`) entonces:

1. Detiene el temporizador de animación (si seguía corriendo).
    
2. Fija la barra de progreso en 100% (solo visualmente, al cerrar).
    
3. Muestra `MainWindow`.
    
4. Cierra el Splash Screen.
    

El ciclo principal de eventos (`app.exec()`) se inicia después de construir el splash y llamar a `start_animation()`, sin esperar a que la carga real termine.
    

---

## 4. Configuración

El módulo `config/settings.py` centraliza la obtención de rutas, configuraciones y determinados valores utilizados por otros componentes de la aplicación.

### 4.1 Resolución de la ruta base

El módulo determina la ubicación base de ejecución comprobando si la aplicación se encuentra ejecutándose como un ejecutable generado mediante PyInstaller (`sys.frozen`).

- En ejecución como aplicación empaquetada, utiliza la ubicación del ejecutable.
    
- En ejecución como código Python, utiliza la ubicación correspondiente al proyecto/script.
    

### 4.2 Carga de configuración

El módulo ejecuta `load_config()` para localizar y cargar:

`app_config.json`

Si el archivo no existe, se genera utilizando el diccionario `DEFAULT_CONFIG`.

Cuando el archivo existe, sus claves se comparan con `DEFAULT_CONFIG` y se incorporan aquellas que estén ausentes.

Este mecanismo permite mantener cierta compatibilidad con configuraciones creadas con versiones anteriores de la aplicación.

### 4.3 Variables de configuración

Los valores obtenidos desde `app_config.json` se exponen mediante variables del módulo para que otros componentes puedan importarlos.

Entre ellas se encuentran valores relacionados con:

- rutas de archivos Excel;
    
- rutas de archivos de provisiones;
    
- ubicaciones de datos;
    
- URLs externas;
    
- otros parámetros de configuración.
    

### 4.3.1 Derivación automática de rutas (no persistida en disco)

Además de comparar contra `DEFAULT_CONFIG`, `settings.py` deriva en memoria dos claves si faltan en `app_config.json`: `LOG_CSV_PATH` (a partir de `LOG_EXCEL_PATH`) y `CASOS_BAJA_CM_PATH` (a partir del directorio de `EXCEL_PATH`). Esta derivación no reescribe el `app_config.json` real en disco, solo completa las variables expuestas por el módulo en memoria.

### 4.4 WATCH_DIR

`WATCH_DIR` se calcula dinámicamente a partir de la ubicación definida mediante `EXCEL_PATH`.

Su finalidad está relacionada con la determinación del directorio que debe ser monitoreado por los componentes correspondientes.

El funcionamiento completo del monitoreo deberá verificarse posteriormente mediante la auditoría de `file_watcher.py` y los componentes que utilicen esta variable.

---

## 5. Archivos de configuración

El sistema utiliza principalmente dos archivos JSON relacionados con la configuración.

### 5.1 app_config.example.json

Funciona como plantilla estructural de la configuración.

Su finalidad es mostrar las claves esperadas sin contener necesariamente los valores específicos de la instalación local.

### 5.2 app_config.json

Es el archivo de configuración utilizado por la instalación local.

Contiene valores específicos de la máquina, incluyendo rutas de archivos y URLs utilizadas por la aplicación.

Debido a que puede contener información específica del entorno corporativo, debe tratarse como configuración local y no debe asumirse automáticamente como un archivo apto para distribución pública.

### 5.3 Inconsistencia detectada

Durante la auditoría se identificó una diferencia en la nomenclatura de la URL de Power BI.

`DEFAULT_CONFIG` y `app_config.example.json` utilizan:

`POWERBI_URL`

Mientras que el archivo `app_config.json` y la lectura realizada en `settings.py` utilizan:

`POWERBI_EMBED_URL`

Esta diferencia constituye una **inconsistencia actual de configuración** y deberá ser revisada posteriormente.

No se realiza ninguna corrección en esta etapa.

---

## 6. Dependencias relevantes

Las dependencias directamente relacionadas con esta fase son principalmente:

### PyQt6

Es la biblioteca utilizada para:

- crear `QApplication`;
    
- administrar el entorno gráfico;
    
- crear ventanas;
    
- ejecutar el Splash Screen;
    
- gestionar el `QTimer`;
    
- iniciar el Event Loop.
    

### Componentes nativos de Windows

`main.py` utiliza `ctypes` para realizar determinadas configuraciones específicas del sistema operativo Windows, relacionadas principalmente con la identificación de la aplicación en la barra de tareas.

Otras dependencias definidas en `requirements.txt` serán documentadas cuando se auditen los componentes que las utilizan.

---

## 7. Flujo resumido

```mermaid
flowchart TD
    A["main.py"] --> B["Configuración del entorno"]
    B --> C["QApplication"]
    C --> D["Estilo + Paleta + Stylesheet"]
    D --> E["Icono + Configuración Windows"]
    E --> F["CustomSplashScreen.start_animation()"]
    F --> H["Instancia MainWindow (inmediato, en paralelo al QTimer visual)"]
    H --> N["MainWindow dispara carga async (data_ready / load_error)"]
    N -->|señal recibida| I["_on_app_ready → Mostrar MainWindow"]
    I --> J["app.exec()"]

    K["config/settings.py"] --> L["Carga app_config.json"]
    L --> M["Variables de configuración"]
    M -.-> H
```

> **Nota:** La relación entre `settings.py` y `MainWindow` es representativa de una dependencia de configuración y no implica que `settings.py` sea ejecutado como una etapa secuencial independiente del arranque. El mecanismo exacto de consumo de configuración será confirmado durante la auditoría de los módulos posteriores.

---

## 8. Observaciones del estado actual

### 8.1 Código duplicado inalcanzable (CORREGIDO — 03-09-2026)

Se había identificado un bloque de código duplicado en `main.py` relacionado con la creación del icono, el Splash Screen y la finalización de la aplicación.

Ese bloque se encontraba después de una llamada previa a `sys.exit(app.exec())`, por lo que nunca podía alcanzarse durante la ejecución normal. Fue eliminado por ser código muerto sin efecto alguno; `main()` termina ahora directamente en el primer `sys.exit(app.exec())`.

**Bug adicional corregido en el mismo bloque:** en el manejo de la excepción fatal de arranque (dentro de `CustomSplashScreen.update_progress`), se llamaba a `datetime.now()` aunque el módulo se importa con `import datetime` (no `from datetime import datetime`), lo que lanzaba `AttributeError`. Como esa llamada estaba envuelta en un `except Exception: pass` más externo, el error se silenciaba y el detalle del error crítico no llegaba a escribirse en el log de arranque. Se corrigió a `datetime.datetime.now()`.

### 8.2 Simulación visual de carga (actualizado 14-09-2026)

Los mensajes mostrados por el Splash Screen en los ticks 15/45/75 están asociados al avance numérico del `QTimer` y no representan eventos reales de procesamiento — son puramente cosméticos.

La creación de `MainWindow` ocurre de inmediato al llamar a `start_animation()`, no en un tick determinado (ver 3.7). El cierre real del splash depende de las señales `data_ready`/`load_error` del `DataManager`, no del avance del contador visual; por eso la barra tiene un tope de 95% y puede quedarse ahí (con el texto "Esperando finalización de carga de datos...") si la carga real tarda más que la animación.

### 8.3 Inconsistencia de configuración

Existe una diferencia entre la clave `POWERBI_URL` definida en `DEFAULT_CONFIG`/`app_config.example.json` y `POWERBI_EMBED_URL`, utilizada por la configuración real y por la lectura realizada desde `settings.py`.

Si `app_config.json` fuera eliminado y se generara nuevamente a partir de `DEFAULT_CONFIG`, esta diferencia podría provocar que la configuración generada no contenga la clave esperada por el código que consume `POWERBI_EMBED_URL`.

Este punto queda registrado como deuda técnica pendiente de revisión.

---

## 9. Dependencias pendientes de auditoría

Para completar la comprensión del arranque y determinar qué procesos se ejecutan durante la creación de la ventana principal, quedan pendientes de revisión:

### `src/ui/main_window.py` → [[03_Vistas_y_Navegacion_UI]]

Debe analizarse su método de inicialización para determinar:

- qué módulos carga;
    
- qué componentes crea;
    
- qué procesos inicia;
    
- qué operaciones pueden ejecutarse durante el arranque;
    
- qué tareas son delegadas a workers;
    
- qué impacto puede tener su inicialización sobre el rendimiento.
    

### `src/core/data_manager.py` → [[02_Motor_de_Datos_Core]]

Debe analizarse para determinar:

- cómo se inicializa;
    
- qué datos administra;
    
- qué componentes dependen de él;
    
- cuándo se cargan los datos;
    
- qué workers o procesos coordina;
    
- cómo se relaciona con el flujo de arranque.
    

El análisis de estos archivos permitirá complementar esta documentación y determinar con mayor precisión la arquitectura real del sistema.

---

## Documentos relacionados

- [[00_Indice_Principal]] — versión en formato de auditoría/hallazgos de este mismo tema (arranque y configuración)
- [[02_Motor_de_Datos_Core]] — DataManager y componentes Core pendientes de auditoría según este documento
- [[03_Vistas_y_Navegacion_UI]] — MainWindow y módulos de interfaz pendientes de auditoría según este documento
- [[08. Arquitectura Visual y Diagramas]] — diagrama visual del flujo de arranque descrito en la sección 3 de este documento
- [[09. Despliegue y Onboarding]] — instalación, requisitos y configuración práctica para un equipo nuevo