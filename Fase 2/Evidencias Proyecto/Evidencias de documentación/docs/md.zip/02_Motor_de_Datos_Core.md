## 1. Visión general del Core

El módulo `src/core/` es el corazón transaccional y de almacenamiento en memoria de la aplicación. Su función general es extraer datos de archivos Excel físicos, validarlos, limpiarlos, mantenerlos en memoria (RAM) usando la librería Pandas y gestionar las escrituras seguras en disco. Pandas y sus DataFrames funcionan efectivamente como el **estado central y fuente de verdad en memoria** de toda la aplicación una vez que se completa el arranque. Todas las vistas consumen copias de estos DataFrames y los modifican directa o indirectamente.

## 2. DataManager

- **Responsabilidad:** Administrar la memoria central, orquestar la carga asíncrona de los Excel y exponer los datos a la interfaz.
    
- **Patrón utilizado:** Implementa un patrón **Singleton** clásico (`__new__` verifica `_instance`), garantizando que todas las pantallas compartan la misma información.
    
- **DataFrames administrados:** Mantiene `df_master` (Comercial/General/Operaciones), `df_prov` (Provisiones), `df_contactos` (Contactos), `df_logs` y `df_deleted` (Auditoría). `df_deleted` solo contiene la **primera hoja** de `RegistroEliminado.xlsx` (se mantiene por compatibilidad, sin consumidores en la UI actual); `deleted_sheets` (expuesto vía `get_deleted_logs_sheets()`) es el dict `{módulo: DataFrame}` con **todas** las hojas del archivo, y es lo que consume la pestaña Papelera de Historial. Ver [[06. Seguridad, Integridad y Resiliencia de Datos]] §8 para el porqué de esta distinción.
    
- **Variables de estado:** Gestiona variables de bloqueo (`is_loading_main`, `is_loading_prov`, `is_loading_contactos`, `is_app_saving`), marcas de tiempo (`save_timestamp`, `last_load_time`), y constantes financieras (`valor_uf`, `valor_civ`, `lista_planes`).
    
- **Señales Qt:** Emite `data_ready`, `load_error`, `provisiones_ready`, `load_provisiones_error`, `contactos_ready` y `load_contactos_error` tras finalizar las cargas en segundo plano. También expone `logs_updated`, una señal liviana emitida por `set_logs_df()` para refrescar solo el historial en RAM sin disparar una recarga completa.
    
- **Carga de datos:** Instancia objetos `QThread` específicos (`MainDataLoaderThread`, `ProvisionesLoaderThread`, `ContactosLoaderThread`) que leen los Excel usando `pd.read_excel`, evitando colapsar la GUI. `MainDataLoaderThread` y `ContactosLoaderThread` reintentan (hasta 5 veces) copiando el Excel bloqueado a un archivo "ghost" temporal (`ghost_main.xlsx`/`ghost_contactos.xlsx`) cuando la lectura falla por `PermissionError` (típico de un Excel abierto por el usuario o bloqueado por SharePoint). `ContactosLoaderThread` además valida estrictamente la columna `ID`: exige que exista y rechaza con error fatal cualquier valor vacío, duplicado o no numérico.
    
- **Diagnóstico:** `get_system_health()` expone el estado de memoria RAM, filas cargadas por DataFrame, conteo de backups existentes y estado de `logs/sistema.log`, consumido por `ConfiguracionModule` para el panel de diagnóstico.
    
- **Relación con otros:** Las interfaces de usuario consumen sus _getters_ (ej. `get_comercial_df()`) que devuelven `.copy()` para aislar la vista de la base. Sin embargo, los módulos de UI inyectan datos directamente en sus variables internas (ej. `dm.df_master = df_m_copy`) tras guardados exitosos.
    

## 3. DataFrameFormatter

- **Propósito:** Preprocesamiento y normalización estricta de DataFrames.
    
- **Validaciones:** `_validate_columns` exige las columnas `VIN` y `CHASIS`. Levanta un `ValueError` si faltan, abortando la carga principal.
    
- **Limpieza y conversiones:** Borra sufijos nulos (`.0`), fuerza enteros donde corresponde y unifica representaciones vacías (`nan`, `NaT`) a cadenas vacías.
    
- **Reglas de negocio (Cálculos):** Recalcula matemáticamente la columna `TÉRMINO CONTRATO` sumando `DURACIÓN (MESES)` a `INICIO CONTRATO` y estandariza todas las fechas a `DD-MM-YYYY` mediante la función `format_date_fast`. También normaliza las columnas `TIPO DE SERVICIO`, `FORMA DE CONTRATO`, `ESTADO COMERCIAL` y `ESTADO DEL CM` (nuevo 11-09-2026, Title Case fijo: `Running`/`Expired`/`Terminated`) contra catálogos fijos (`TIPO_SERVICIO_MAP`, `FORMA_CONTRATO_MAP`, `ESTADO_COMERCIAL_MAP`, `ESTADO_DEL_CM_MAP` en `src/core/constants.py`), dejando intacto cualquier valor no mapeado. Detalle de negocio de `ESTADO DEL CM` en [[07. Procesos y Reglas de Negocio]] §1 y §4. Además calcula la columna `ETAPA GESTIÓN` (`calcular_etapa_gestion_esperada`) combinando `TIPO DE FACTURACION` (prioridad 1) y `ESTADO_COMERCIAL_ETAPA_MAP` (prioridad 2), como única fuente de verdad de esa columna.
    
- **Quién lo utiliza:** Es invocado por `MainDataLoaderThread` (dentro de DataManager) y `ExcelReader` (para snapshots). También es utilizado por `RMJaviSyncWorker` para limpiar la base tras la sincronización.
    

## 4. ExcelReader

- **Archivos que lee:** Principalmente `EXCEL_PATH`, `LOG_CSV_PATH` (el historial oficial `LogApp.csv`, leído vía `pd.read_csv`; ya no `LOG_EXCEL_PATH`) y `DELETED_LOG_EXCEL_PATH`.
    
- **Snapshot y compare_snapshot:** Crea una copia binaria rápida (`.snapshot_comercial.pkl`) de la base comercial usando la librería `pickle`. Su método `compare_snapshot` extrae el Excel nuevamente y cruza ambos DataFrames usando la columna `VIN` como identificador único para detectar Altas, Bajas y Modificaciones externas. Posee un mecanismo de "Auto-Heal" que ignora los cambios si superan los 200 registros.
    
- **Duplicación confirmada:** NO es utilizado por `DataManager` para cargar la RAM. Duplica la lógica de lectura ejecutando su propio `pd.read_excel(EXCEL_PATH)` de forma separada.
    

## 5. ExcelWriter

- **Métodos y archivos:** Expone `overwrite_dataframe`, `update_cells`, `delete_row` y `add_new_row`. Modifica dinámicamente cualquier ruta que se le inyecte por el parámetro `custom_filepath`.
    
- **Ciclo de vida (Backups y Temporales):**
    
    1. Activa `dm.is_app_saving = True` y `save_timestamp`.
        
    2. Ejecuta `_crear_backup`, clonando el archivo original en `/data/backups/` con fecha y hora. **Confirmado:** `update_cells`, `add_new_row`, `delete_row` y `overwrite_dataframe` verifican `self.last_backup_ok` justo después y abortan la escritura (sin tocar el archivo real) si el backup falló.
        
    3. Crea un archivo temporal UUID en `/data/temp/` y clona el original allí.
        
    4. Modifica el temporal usando `openpyxl` (o `pandas` para overwrite).
        
    5. Ejecuta `os.fsync` para asegurar escritura en disco físico.
        
    6. Copia el temporal sobre el archivo original con `shutil.copy2` (no es un `os.replace`/rename atómico de sistema operativo, a diferencia de la migración de historiales legacy — ver 5.1 — que sí usa `os.replace`) y registra la acción en `LogApp.csv` (historial oficial de modificaciones) o `RegistroEliminado.xlsx` (papelera de eliminados).
        
- **Concurrencia:** Los métodos de `ExcelWriter` son **100% sincrónicos y bloqueantes** internamente.
    
- **Confirmado — `_log_deleted` protegido:** El registro de eliminaciones (`RegistroEliminado.xlsx`) también sigue el Punto C: crea backup antes de guardar y, si no puede leer el archivo existente, aborta el registro sin modificarlo en vez de recrearlo desde cero. Además, si el esquema de columnas del módulo de origen cambia respecto a la hoja ya existente, `_log_deleted` no la sobrescribe: crea una hoja nueva versionada (ej. `"Base (2)"`, vía `_siguiente_nombre_hoja_version`) para no mezclar ni corromper el histórico con columnas incompatibles. Detalle e historial del hallazgo en [[06. Seguridad, Integridad y Resiliencia de Datos]].
    

## 5.1 mail_registro.py (`src/services/`)

> Nota: este módulo vive en `src/services/`, no en `src/core/`. Se documenta aquí, junto a `ExcelWriter`, por compartir el mismo tipo de responsabilidad (persistencia de un historial transaccional) y patrones (migración atómica no destructiva, escritura tolerante a fallos).

- **Responsabilidad:** Persistir el historial de correos enviados (`Historial_Envios_VC.csv`) de forma independiente de la UI. Antes, `mail_dialog.py` leía y reescribía `Historial_Envios_VC.xlsx` completo directamente dentro de `OutlookSenderThread`.
    
- **Por qué se separó de la UI:** Mantener la lógica de registro fuera de `mail_dialog.py` permite (a) probarla con pruebas unitarias puras sin levantar PyQt6 ni mockear Outlook/COM, y (b) aplicarle el mismo patrón append-only ya validado en `LogApp.csv` sin mezclarlo con la lógica de envío de correos.
    
- **Funciones expuestas:**
    - `construir_registro(id_envio, fecha_hora, tipo_correo, razon_social, chasis, destinatario, estado, asunto)`: arma un registro de historial con las claves de `_COLUMNAS`. **Nuevo (03-09-2026):** única fuente de verdad del esquema del historial — antes `OutlookSenderThread.run()` armaba el diccionario a mano, duplicando los nombres de columna ya definidos en `_COLUMNAS`.
    - `registrar_envios(historial_records)`: agrega filas nuevas al CSV oficial sin releer el historial completo (append-only). Nunca lanza excepción; devuelve `True`/`False`.
    - `leer_historial()`: devuelve el historial completo como DataFrame (usado por `RegistroEnviosDialog` en `mail_dialog.py` para mostrarlo en pantalla).
    - `migrar_historial_legacy()`: migración única e idempotente desde el `.xlsx` legado hacia el CSV oficial, con verificación de conteo de filas antes de reemplazar (`os.replace` atómico). El `.xlsx` original nunca se modifica ni se borra. Se invoca automáticamente al inicio de `registrar_envios` y `leer_historial`.
    
- **Quién lo usa:** `OutlookSenderThread.run()` (en `mail_dialog.py`) llama a `construir_registro` para armar cada fila y luego a `registrar_envios` tras el envío, propagando el resultado (`registro_ok`) en `finished_signal` para que la UI pueda avisar si el registro falló aunque el correo se haya enviado. `RegistroEnviosDialog` (diálogo en `mail_dialog.py`, reutiliza `VolvoTableWidget`/`PandasTableModel`) llama a `leer_historial` para mostrar el historial completo.
    
- **Relación con los demás servicios de Correos (03-09-2026):** `mail_registro.py` sigue siendo exclusivamente el historial. La preparación de destinatarios/plantillas (`src/services/mail_service.py`), el cruce/persistencia de `Correos.xlsx` (`src/services/mail_sync_service.py`) y el puente Contactos→Correos.xlsx para altas puntuales de contacto (`src/services/contacto_correo_service.py`, nuevo 03-09-2026) son servicios hermanos, no documentados en esta sección por no compartir su responsabilidad de persistencia de historial — ver [[03_Vistas_y_Navegacion_UI]] §8 y [[08. Arquitectura Visual y Diagramas]] §7.1 para su rol dentro del flujo de Correos.

## 6. FileWatcher

- **Funcionamiento:** Monitoriza la carpeta `WATCH_DIR` usando la librería `watchdog` dentro del hilo `WatchdogThread`.
    
- **Relación con DataManager (Debouncer/Silenciador):** Posee un freno de 5 segundos para eventos en ráfaga. Su función vital es el silenciador: consulta `dm.is_app_saving` y `dm.save_timestamp`; si la modificación ocurrió hace menos de 10 segundos y la bandera está activa, descarta el evento porque el origen de la escritura fue la propia aplicación (`ExcelWriter`). De lo contrario, emite `file_changed_signal`.
    

## 7. SharePointSync

- **Funcionamiento REAL:** No utiliza API. Simula una descarga humana abriendo el enlace de SharePoint en el navegador por defecto del sistema (`webbrowser.open`).
    
- **Detección:** Escanea (sin recursividad, solo el nivel superior vía `glob.glob`) el directorio de "Descargas" del SO (`QStandardPaths.DownloadLocation`) hasta por 60 segundos buscando un archivo que coincida con `Provision Contratos-RpySS*.xlsx`.
    
- **Procesamiento y Deduplicación:** Mueve el archivo a `/data/temp/`, lee la hoja "2026", formatea las fechas e identifica nuevos registros filtrando aquellos cuya combinación `AÑO - MES_VIN` ya exista en el Excel local `provisionFelipe.xlsx`.
    
- **Inyección (Copiar Fórmulas):** Abre el Excel local con `openpyxl`, añade las filas nuevas al final de la tabla e inyecta dinámicamente las fórmulas matemáticas (usando `Translator` de `openpyxl.formula.translate`) arrastrándolas desde la fila superior.
    
- **Excepción al ciclo de vida seguro de la sección 5:** la fase de inyección solo usa `ExcelWriter()._crear_backup()` para el respaldo previo; el guardado real es `wb.save(PROVISION_EXCEL_PATH)` directo, sin archivo temporal en `/data/temp/` ni `os.fsync` de resguardo — a diferencia del resto de escrituras de la aplicación. `SharePointSyncWorker` es además una única instancia de `QThread` reutilizada en dos fases (detección e inyección) mediante el flag `self.is_injecting`, no dos hilos separados.
    

## 8. Integración de la Interfaz con el Core (Auditoría de UI)

> Ver el lado UI de esta integración en [[03_Vistas_y_Navegacion_UI]].

- **Quién instancia:**
    
    - `DataManager`: Es instanciado múltiples veces (al ser Singleton retorna la misma memoria) en `MainWindow`, `ComercialModule`, `ProvisionesModule` y `ContactosModule`.
        
    - `ExcelReader`: Solo es instanciado por `MainWindow` para utilizar su método de comparación.
        
    - `ExcelWriter`: Instanciado por `ComercialModule`, `ProvisionesModule`, `ContactosModule` y `RescateWorker`. **Actualizado (03-09-2026):** también instanciado directamente por `MailDialog` (`_abrir_agregar_correo`, para `add_new_row` en `contactos.xlsx`) y por `contacto_correo_service.py` (para `update_cells` en `Correos.xlsx`) — ver [[03_Vistas_y_Navegacion_UI]] §8.
        
- **Quién inicia las cargas:**
    
    - `load_data_async()`: Lanzado por `MainWindow` en el arranque y en los botones "Recargar" o funciones de auto-heal de Provisiones y Comercial.
        
    - `load_provisiones_async()`: Lanzado internamente en cadena por `_ejecutar_cargas()` de `ProvisionesModule`.
        
    - `load_contactos_async()`: Lanzado directamente por `ContactosModule` al cargarse. **Actualizado (03-09-2026):** también lanzado por `MailDialog` tras agregar un contacto desde "Agregar correo relacionado a esta empresa", para mantener el caché global (`df_contactos`) sincronizado igual que hace `ContactosModule` tras su propia alta.
        
    - **Actualizado (02-09-2026):** `ContactosModule` ya no depende de `direcciones.xlsx` (archivo local legado, eliminado de `app_config.json` y de todo el código). En su lugar, lanza en paralelo un segundo worker (`PowerBiSyncWorker`) que lee `POWERBI_EXCEL_PATH` (`BBDD CLIENTES CM.xlsx`) de forma asíncrona para obtener las direcciones/empresas. La pantalla de Contactos muestra un loading screen (spinner, igual al de Provisiones) hasta que ambas cargas (`contactos.xlsx` vía `load_contactos_async` y `BBDD CLIENTES CM.xlsx` vía `PowerBiSyncWorker`) terminan.
        
- **Quien escucha señales:**
    
    - `data_ready`: Escuchada por `MainWindow` (para desbloquear el menú e iniciar Watchdog) y `ComercialModule` (para repoblar la tabla).
        
    - `provisiones_ready` y `contactos_ready`: Escuchadas por sus respectivos módulos para inicializar las tablas.
        
- **Hilos de Escritura (Crucial para Concurrencia):**
    
    Como `ExcelWriter` es bloqueante, la UI ha implementado wrappers de `QThread` para cada operación de escritura. En lugar de llamar al `writer` directamente, los módulos instancian hilos paralelos:
    
    - Comercial: `SaveExcelThread`, `AddRowThread`, `DeleteRowThread`.
        
    - Provisiones: `SaveProvisionesThread`.
        
    - Contactos: `SaveContactosThread`, `AddContactoThread`, `DeleteContactoThread`.

    - **Excepción detectada (NUEVO — 03-09-2026):** `MailDialog._abrir_agregar_correo()` llama a `ExcelWriter().add_new_row(...)` y a `contacto_correo_service.actualizar_correo_por_cdb()` (que a su vez llama a `ExcelWriter().update_cells(...)`) **directamente en el hilo principal, sin wrapper `QThread`**, rompiendo el patrón de esta sección. Se preservó así porque es el comportamiento que ya tenía el flujo de sincronización de Correos (`SyncCorreosDialog.save_data()` también llama a `mail_sync_service.guardar_correos_excel()` de forma síncrona) y no se pidió cambiarlo; puede congelar brevemente la UI mientras escribe ambos Excel. Riesgo menor, no corregido — ver [[03_Vistas_y_Navegacion_UI]] §10 para el resto de bloqueos síncronos conocidos del módulo de Correos.
        
    - **Excepción preexistente confirmada (auditoría 03-09-2026):** `CostosDialog.save_and_close()` (en `provisiones.py`) también escribe `provisionFelipe.xlsx` **directamente en el hilo principal** (`openpyxl.load_workbook`/`wb.save`, con `ExcelWriter._crear_backup()` previo pero sin wrapper `QThread`), el mismo patrón de excepción que `MailDialog._abrir_agregar_correo()`. No es una regresión de esta fecha ni se corrigió: no se pidió, y el backup previo sigue siendo obligatorio y bloqueante ante fallo — solo un riesgo de UI congelada brevemente al guardar Ajustes de Costos.
        
- **Actualización del Estado en RAM (Inyección Post-Guardado):** Para evitar leer el archivo completo desde el disco tras cada guardado, los módulos incluyen código que inyecta los datos directamente al Singleton. Por ejemplo, `ComercialModule` en su función `_on_save_finished` realiza un volcado: `df_m_copy.loc[mask, col] = val` y luego `dm.df_master = df_m_copy`.
    
- **Cruce de Módulos (Provisiones a Comercial):** Cuando se guarda una provisión, el hilo `SaveProvisionesThread` verifica si hay datos comerciales afectados (`cross_updates`). De ser así, ejecuta un segundo guardado mediante `ExcelWriter.update_cells` dirigido al archivo comercial ("PruebasFM.xlsx") y posteriormente actualiza ambos DataFrames (`dm.df_master` y `dm.df_prov`) en memoria. **Actualizado (03-09-2026):** la normalización de `provisiones_changes` (payload para `update_cells` sobre Provisiones) y el cálculo de `PERIODO INTERNO` se extrajeron a `provisiones_services.construir_cambios_provisiones()`/`convertir_periodo_interno()`, funciones puras testeadas sin PyQt6. El resto del bloque (`cross_updates`, lectura de `INICIO CONTRATO` en `df_master` y proyección de `TÉRMINO CONTRATO` vía `relativedelta`) permanece sin cambios dentro del thread — deliberadamente no extraído por duplicar `DataFrameFormatter.calcular_termino()`.
    
- **Reacción a FileWatcher (Cambio Externo):** El `Watchdog` emite una señal que atrapa `MainWindow`. Este ejecuta `CompareSnapshotThread` (usando `ExcelReader`). Al finalizar, notifica al usuario; si el usuario acepta, `MainWindow` fuerza un `data_manager.load_data_async()` para actualizar la aplicación completa con la base externa.
    

## 9. Concurrencia y rendimiento

- **Asincronía real (QThread):** Todas las cargas pesadas de archivos (`pd.read_excel`), todas las modificaciones CRUD sobre Excel (`ExcelWriter`), el monitoreo del disco (`Watchdog`) y las sincronizaciones de SharePoint se ejecutan estrictamente en hilos separados (Background Threads).
    
- **Protección del Hilo Principal:** Gracias a los Wrappers creados en la UI (ej. `SaveExcelThread`), la interfaz gráfica **no sufre congelamientos confirmados** durante lectura o escritura.
    
- **Cuellos de Botella Confirmados:** El formateo de fechas (`DataFrameFormatter`) itera masivamente strings y el `compare_snapshot` procesa el Excel entero cruzándolo con la RAM. Aunque están aislados en hilos y no congelan la interfaz, impactan fuertemente en el tiempo de procesamiento (Load Time).
    

## 10. Persistencia

- **Fuente Persistente (Maestros):** Los archivos físicos locales (ej. `PruebasFM.xlsx`, `provisionFelipe.xlsx`).
    
- **Estado en Memoria:** DataFrames dentro del Singleton `DataManager`.
    
- **Archivos Temporales:** `/data/temp/` almacena clones de Excel durante escrituras y cruces asíncronos para proteger el original si falla el proceso.
    
- **Backups:** tres mecanismos independientes y complementarios (detalle en [[06. Seguridad, Integridad y Resiliencia de Datos]]):
    - `/data/backups/` — copia previa de UN archivo justo antes de modificarlo (`ExcelWriter._crear_backup`), últimas 10 instantáneas por archivo.
    - `/data/backup_auto/` — snapshot completo automático de todos los archivos maestros, disparado al iniciar la app los viernes (máximo uno por semana ISO), retiene los últimos 5. Implementado por `BackupManager` (`src/core/backup_manager.py`), ejecutado fuera del hilo principal por `BackupWorker` (`QThread`).
    - `/data/backupManual/` — snapshot completo bajo demanda desde Configuración ("Realizar backup completo"), sin retención automática. También implementado por `BackupManager`/`BackupWorker`.
    
- **Logs de Auditoría:** `LogApp.csv` (historial oficial de modificaciones, migrado una única vez desde el antiguo `LogApp.xlsx` + `LogApp_incremental.csv`) y `RegistroEliminado.xlsx` (papelera de eliminados) almacenan trazas de las escrituras. De forma análoga, `Historial_Envios_VC.csv` (gestionado por `mail_registro.py`, ver sección 5.1) almacena el historial de correos enviados, migrado una única vez desde el antiguo `Historial_Envios_VC.xlsx`.
    
- **Caché:** `.snapshot_comercial.pkl` actúa como caché rápido del último estado conocido para detectar colisiones.
    

## 11. Comparación con ARCHITECTURE.md

- Lógica Asíncrona (Data Manager y UI Workers): **CONFIRMADO**. El código demuestra el uso exhaustivo de QThread.
    
- Base Comercial como fuente de verdad: **CONFIRMADO**. Todas las rutas apuntan a un Excel maestro.
    
- Mecanismo de Temp y Backups: **CONFIRMADO**.
    
- Watchdog y Freno de eventos: **CONFIRMADO**.
    
- Base de Datos SQL: **CONFIRMADO AUSENTE**. Todo es Pandas y Openpyxl.
    

## 12. Problemas y Riesgos Confirmados

### Problemas confirmados

- **Ruptura del Encapsulamiento del Singleton:** Los módulos de UI (Comercial, Provisiones, Contactos) modifican directamente los atributos internos del `DataManager` (ej. `dm.df_master = df_m_copy`) en lugar de utilizar métodos de actualización (`Setters`). Esto es una violación arquitectónica clara (análisis extendido en [[04. Arquitectura y Patrones del Sistema]]).
    
- **Duplicación de código de lectura:** `ExcelReader` implementa lógicas de Pandas redundantes que ya realiza `DataManager`.
    

### Riesgos potenciales

- **Sincronización Frágil:** `SharePointSyncWorker` y `RescateWorker` asumen que el navegador abrirá, el usuario está logueado, y la ruta de Descargas es `C:\Users\...`. Cualquier intervención del OS fallará el `time.sleep`.
    
- **Inconsistencia RAM vs Disco:** Al inyectar los cambios en RAM manualmente después de guardar con `ExcelWriter` (para no recargar el Excel completo), si la lógica de inyección de un módulo no es idéntica a lo que Openpyxl escribió, la interfaz mostrará algo distinto a lo que hay en el archivo hasta el próximo reinicio.
    - **Confirmado como bug real (02-09-2026):** En `ComercialModule._on_save_finished`, la inyección post-guardado reasignaba `self.df_base` desde `get_comercial_df()` sin reaplicar el mismo preprocesamiento que `load_data()` (limpieza de `CDB`/`DURACIÓN (MESES)`, ajuste de `TÉRMINO CONTRATO` y, sobre todo, el cálculo de la columna auxiliar `PAGO CM_NUM`). Como esa ruta además activa `_skip_self_triggered_reload` (evita que `_on_global_data_ready` vuelva a llamar `load_data()`), el `df_base` quedaba permanentemente incompleto tras cada guardado. El siguiente uso del buscador global (`MainWindow._on_global_search` → `filter_table()`) lanzaba `KeyError: 'PAGO CM_NUM'` y crasheaba la app. **Corregido:** se extrajo el preprocesamiento a `ComercialModule._procesar_df_base()`, usado ahora tanto por `load_data()` como por `_on_save_finished()`. Detalle de módulo en [[03_Vistas_y_Navegacion_UI]].

---

## Documentos relacionados

- [[03_Vistas_y_Navegacion_UI]] — cómo la UI consume e integra estos componentes
- [[04. Arquitectura y Patrones del Sistema]] — patrones de diseño (Singleton, Store Global) aplicados a DataManager
- [[05. Flujos de Datos y Sincronización]] — flujos que orquestan ExcelReader, ExcelWriter y FileWatcher
- [[06. Seguridad, Integridad y Resiliencia de Datos]] — mecanismos de seguridad de ExcelWriter y FileWatcher en detalle
- [[07. Procesos y Reglas de Negocio]] — reglas que dependen de DataFrameFormatter y ExcelReader
- [[08. Arquitectura Visual y Diagramas]] — diagrama visual del DataManager y del flujo de guardado (§2 y §3)